CraftChat - Offline P2P Encrypted Chat & Call for Linux
======================================================
วิธีใช้งาน:
1. ดับเบิลคลิกไฟล์ 'craftchat.sh' หรือ 'craft-chat-gui'
2. หรือเปิด Terminal ในโฟลเดอร์นี้ แล้วพิมพ์:
   ./craftchat.sh
