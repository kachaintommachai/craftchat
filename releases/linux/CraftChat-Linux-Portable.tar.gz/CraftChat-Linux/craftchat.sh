#!/usr/bin/env bash
HERE="$(dirname "$(readlink -f "$0")")"
cd "$HERE"
chmod +x ./craft-chat-gui ./craft-chat-daemon 2>/dev/null || true
echo "Starting CraftChat GUI..."
exec ./craft-chat-gui "$@"
