CraftChat - Offline P2P Encrypted Chat & Call for Windows
=========================================================
วิธีใช้งาน:
1. ดับเบิลคลิกที่ 'CraftChat.exe'
2. ระบบจะเปิดหน้าต่าง GUI แบบ Standalone Application ให้ทันที (ผ่าน Microsoft Edge / Chrome App Mode)
3. ใช้งานระบบแชท ส่งไฟล์ โทรเสียง และสติกเกอร์ได้ทันที โดยไม่ต้องเชื่อมต่ออินเทอร์เน็ต
